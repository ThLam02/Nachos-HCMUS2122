#include "syscall.h"

void main()
{
    char i = 32;
    int num;
    for (;i < 127 ; i++)
    {
        PrintNum((int)i); 
        PrintString(" : ");
        PrintChar(i);

        num = ((int)i - 32) % 7;

        if(num != 0 && i != 0)  PrintString("\t\t");
        else                    PrintChar('\n');
        
    }
    Halt();
    return;
}
