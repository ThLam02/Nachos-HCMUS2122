#include "syscall.h"

void main(){
    PrintNum(RandomNum());
    Halt();
    return;
}