/*printChar.c
*
*   
*
*/

#include "syscall.h"

void
main()
{
    PrintChar(ReadChar());
    Halt();
  /* not reached */
  return;
}
