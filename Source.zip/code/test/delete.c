#include "syscall.h"


int main(){
    char* filename;
    PrintString("Enter filename: ");
    ReadString(filename, 255);
    Remove(filename);
    
    Halt();
    return 0;
}