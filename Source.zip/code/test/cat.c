#include "syscall.h"

void readFile(char* str);

int main(){
    char str[256];
    PrintString("\nEnter filename: ");
    readFile(str);

    if(str[0] != '\0'){
        PrintString("\nString from file:\n");
        PrintString(str);
        PrintString("\n");
    }
    Halt();
    return 0;
}

void readFile(char* str){
    OpenFileId idFile;
    char *filename = "";
    int cnt = 0;
    while (cnt < 3){
        ReadString(filename, 256);
        if((idFile = Open(filename)) != -1){
            if(Seek(0, idFile) != -1){
                Read(str, MAX_LENGTH, idFile);
                Close(idFile);
                return;
            }
        }
        else if(cnt == 2) {
            PrintString("\nWrong input more than 3!\nEnd processing...\n");
            str[0] = '\0';
            return;
        }
        else{
            PrintString("\nRetype file name: ");
        }
        cnt++;
    }  
}