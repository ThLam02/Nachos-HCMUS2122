/*
*
*   Use bubble sort for integer arrays
*
*/

#include "syscall.h"


void DescBubbleSort(int arr[], int n);
void AscBubbleSort(int arr[], int n);
void outputArr(int arr[], int n);
void inputArr(int arr[], int* n);

void main(){
    int arr[100], n, ans;

    //Enter array
    inputArr(arr, &n);

    
    PrintString("\n1: Sorting increases, others: Sorting decreases\nYour choice: ");
    ans = ReadNum();
    if(ans != 1)  DescBubbleSort(arr, n);
    else          AscBubbleSort(arr, n);
    PrintString("\nSorting complete!!!\n");

    //Display array
    outputArr(arr, n);

    Halt();
    return;
}

void inputArr(int arr[], int* n){
    int i;
    while(1){
        PrintString("Enter n (n <= 100): ");
        *n = ReadNum();
        if(*n > 0 || *n <= 100) break;
        PrintString("Unvalid value!!!\nPlease try again...\n\n");
    }

    for(i = 0; i < *n; i++){
        PrintString("A[" );
        PrintNum(i);
        PrintString("] = ");
        arr[i] = ReadNum();
    }
}

void outputArr(int arr[], int n){
    int i;
    PrintString("A[] = {");
    for(i = 0; i < n; i++){
        PrintNum(arr[i]);

        if(i != n - 1)  PrintChar(',');
        else            PrintChar('}');
    }
    PrintChar('\n');
}

void swap(int* a, int* b){
    int temp = *a;
    *a = *b;
    *b = temp;
}

void AscBubbleSort(int arr[], int n)
{
    int i, j, haveSwap = 0;
    for (i = 0; i < n-1; i++){
        haveSwap = 0;
        for (j = 0; j < n-i-1; j++){
            if (arr[j] > arr[j+1]){
                swap(&arr[j], &arr[j+1]);
                haveSwap = 1; 
            }
        }
        
        if(haveSwap == 0){
            break;
        }
    }
}

void DescBubbleSort(int arr[], int n)
{
    int i, j, haveSwap = 0;
    for (i = 0; i < n-1; i++){
        haveSwap = 0;
        for (j = 0; j < n-i-1; j++){
            if (arr[j] < arr[j+1]){
                swap(&arr[j], &arr[j+1]);
                haveSwap = 1; 
            }
        }

        if(haveSwap == 0){
            break;
        }
    }
}