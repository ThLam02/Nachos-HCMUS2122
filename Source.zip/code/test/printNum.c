
#include "syscall.h"

void
main()
{
    PrintNum(ReadNum());
    Halt();
    return;
}
