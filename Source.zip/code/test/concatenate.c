#include "syscall.h"

int lengthString(char* str);
void readFile(char* str);

int main(){
    char str1[256], str2[256];
    OpenFileId idF;
    PrintString("\n***Concatenate from file 1 and file 2 to file 3 with filename \"Concatenate.txt\"***\n\n");
    PrintString("Enter the original filename 1: ");
    readFile(str1);

    PrintString("Enter the original filename 2: ");
    readFile(str2);

    if(str1[0] != '\0' && str2[0] != '\0'){
        Create("Concatenate.txt");
        if((idF = Open("Concatenate.txt")) != -1){
            if(Seek(0, idF) != -1){
                if(Write(str1, lengthString(str1), idF) != -1 && Seek(lengthString(str1), idF) != -1){
                    Write(str2, lengthString(str2), idF);
                }
            }
            Close(idF);
        }
    }
    Halt();
    return 0;
}

int lengthString(char* str){
    if(*str == '\0') return 0;
    return lengthString(str + 1) + 1;
}


void readFile(char* str){
    OpenFileId idFile;
    char *filename = "";
    int cnt = 0;
    while (cnt < 3){
        ReadString(filename, 255);
        if((idFile = Open(filename)) != -1){
            if(Seek(0, idFile) != -1){
                Read(str, MAX_LENGTH, idFile);
                Close(idFile);
                return; 
            }
        }
        else if(cnt == 2) {
            PrintString("\nWrong input more than 3!\nEnd processing...\n");
            str[0] = '\0';
            return;
        }
        else{
            PrintString("\nRetype file name: ");
        }
        cnt++;
    }
    
}