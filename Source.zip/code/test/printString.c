
#include "syscall.h"

void main(){
    char str[1024]; 
    PrintString("Enter string: ");
    ReadString(str, 1023);
    PrintString(str);
    Halt();
    return;
}