#include "syscall.h"

int main(){
    Create("hello.txt");
    Halt();
    return 0;
}