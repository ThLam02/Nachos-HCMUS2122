#include "syscall.h"

int lengthString(char* str);
void readFile(char* str);

int main(){
    char* destination, str[256];
    OpenFileId idFile;
    int cnt = 0;

    PrintString("Enter the original filename: ");
    readFile(str);
    if(str[0] != '\0'){
        PrintString("Enter the destination filename: ");
        while (cnt < 3)
        {
            ReadString(destination, 255);
            
            if((idFile = Open(destination)) == -1){
                if(cnt == 2) {
                    PrintString("\nWrong input more than 3!\nEnd processing...\n");
                    break;
                }
                else PrintString("\nRetype file name: ");
                cnt++;
            }   
            else {
                Write(str, lengthString(str), idFile);
                Close(idFile);
                break;  
            }
        }
    }
    Halt();
    return 0;
}

int lengthString(char* str){
    if(*str == '\0') return 0;
    return lengthString(str + 1) + 1;
}

void readFile(char* str){
    OpenFileId idFile;
    char *filename = "";
    int cnt = 0;
    while (cnt < 3){
        ReadString(filename, 256);
        if((idFile = Open(filename)) != -1){
            if(Seek(0, idFile) != -1){
                Read(str, MAX_LENGTH, idFile);
                Close(idFile);
                return;
            }
        }
        else if(cnt == 2) {
            PrintString("\nWrong input more than 3!\nEnd processing...\n");
            str[0] = '\0';
            return;
        }
        else{
            PrintString("\nRetype file name: ");
        }
        cnt++;
    }  
}