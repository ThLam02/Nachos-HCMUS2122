/* help.c
*   
*       Introduction about my group and description about ASCII and Sort
*
*/

#include "syscall.h"


void main(){
    PrintString("Information of our group:\n\t1. 20127557 Tran Bao Long\n\t2. 20127402 Bui Thanh Lam\n\n");
    PrintString
    (
        "Ascii: at directory code, run \"build.linux -x printRandomNum\"."  
        " Then, the table ASCII is shown and \"Syscall halt\" is called.\n"
    );
    PrintString
    (
        "Sort: at directory code, run \"build.linux -x sortArr\".\n"  
        "\t-Step 1: Enter n (the length of the array, 0 < n <= 100)\n" 
        "\t-Step 2: Enter n elements of the array\n"  
        "\t-Step 3: Enter the order you want to sort the array with (1: Sorting increases, others: Sorting decreases)\n" 
        "\t-At the Last: The program will print out the soted array and \"Syscall halt\" is called.\n"
    );
    Halt();
    return;
}