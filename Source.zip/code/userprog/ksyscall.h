/**************************************************************
 *
 * userprog/ksyscall.h
 *
 * Kernel interface for systemcalls 
 *
 * by Marcus Voelp  (c) Universitaet Karlsruhe
 *
 **************************************************************/

#ifndef __USERPROG_KSYSCALL_H__ 
#define __USERPROG_KSYSCALL_H__ 

#include "kernel.h"
#include "synchconsole.h"
#include "stdint-gcc.h"
#include "syscall.h"

#define MaxFileLength 32
#define LIMIT 1024

void SysHalt()
{
    kernel->interrupt->Halt();
}

int SysAdd(int op1, int op2)
{
    return op1 + op2;
}


int lengthString(char* str){
    if(*str == '\0') return 0;
    return lengthString(str + 1) + 1;
}
int ToInt(char* str)
{
    //Check the string which was entered
    if (str[0] == '\0')
        return 0;
    int check = /*Max int32*/2147483647 / 10, len = strlen(str); 
    int numb = 0, signNum = 1, i = 0;

    //Check sign of integer and size of string
    if (str[0] == '-') {
        if (len > 11)
            return 0;
        signNum = -1;
        i = 1;
    }
    else if (len > 10)
        return 0;

    //Check integer
    while (str[i] != '\0')
    {
        //ignore the string's space
        if (str[i] == ' ') {
            i++;
            continue;
        }
        if (str[i] < '0' || str[i] > '9')
            return 0;
        else {
            //Check the integer
            if (numb == check)
                if (!((signNum > 0 && str[i] - 48 <= 7 && i == 9) ||
                    (signNum < 0 && str[i] - 48 <= 8 && i == 10)))
                    return 0;
            //Change from char to integer if this char is a integer   
            numb = numb * 10 + str[i] - 48;
        }
        i++;
    }
    return numb * signNum;
}

int digit(int num) {
    if (num == 0) return 0;
    return 1 + digit(num / 10);
}
char* toString(int num) {
    if(num == 0) return "0";

    int d = digit(num), i = d - 1;
    char* str = new char[d];

    while (i != -1)
    {
        str[i--] = num % 10 + '0';
        num /= 10;
    }
    str[d] = '\0';
    return str;
}

int sysRandomNum() {
    srand(time(NULL)); 
	int res;
    res = rand() % (2147483646 - 0 + 1) + 0 ;
    return res;
}


/*
    Input:  - User space address (int)
            - Limit of buffer (int)
    Output: - Buffer (char*)
    Purpose: Copy buffer from User memory space to System memory space 
*/


char* User2System(int virtAddr, int limit)  
{
    int i;// index
    int oneChar;
    char* kernelBuf = NULL;
    kernelBuf = new char[limit + 1];//need for terminal string

    if (kernelBuf == NULL)
        return kernelBuf;

    memset(kernelBuf, 0,limit + 1);

    //printf("\n Filename u2s:");
    for (i = 0 ; i < limit ;i++)
    {
        kernel->machine->ReadMem(virtAddr + i, 1, &oneChar);
        kernelBuf[i] = (char)oneChar;
        //printf("%c",kernelBuf[i]);
        if (oneChar == 0)
            break;
    }
    return kernelBuf;
}

/*
Input:  - User space address (int)
        - Limit of buffer (int)
        - Buffer (char[])
Output: - Number of bytes copied (int)
Purpose: Copy buffer from System memory space to User memory space
*/

int System2User(int virtAddr, int len, char* buffer)
{
    if (len < 0) return -1;
    if (len == 0)  return len;
    int i = 0;
    int oneChar = 0 ;
    do{
        oneChar = (int) buffer[i];
        kernel->machine->WriteMem(virtAddr + i , 1 , oneChar);
        i++;
    }while(i < len && oneChar != 0);
    return i;
}
/*====================================================================================================================================
**                                            FUNCTION OF SYSTEM CALL
**====================================================================================================================================                                          
**/

void 
upProgramCounter(){
/* Modify return point */
    /* set previous programm counter (debugging only)*/
    kernel->machine->WriteRegister(PrevPCReg, kernel->machine->ReadRegister(PCReg));

    /* set programm counter to next instruction (all Instructions are 4 byte wide)*/
    kernel->machine->WriteRegister(PCReg, kernel->machine->ReadRegister(PCReg) + 4);

    /* set next programm counter for brach execution */
    kernel->machine->WriteRegister(NextPCReg, kernel->machine->ReadRegister(PCReg) + 4);
}         
void 
handle_SC_Halt(){
    DEBUG(dbgSys, "Shutdown, initiated by user program.\n");
    SysHalt();
}

void
handle_SC_Add(){
    DEBUG(dbgSys, "Add " << kernel->machine->ReadRegister(4) << " + " << kernel->machine->ReadRegister(5) << "\n");

    /* Process SysAdd Systemcall*/
    int result;
    result = SysAdd(/* int op1 */(int)kernel->machine->ReadRegister(4),
                    /* int op2 */(int)kernel->machine->ReadRegister(5));

    DEBUG(dbgSys, "Add returning with " << result << "\n");
    /* Prepare Result */
    kernel->machine->WriteRegister(2, (int)result);
    return upProgramCounter();
}

void
handle_SC_ReadNum(){
    //GetString in class SynchConsoleInput is a function to get a string from user input.
    char* str = kernel->synchConsoleIn->GetString();

    //Change string of numbers to numbers
    int result = ToInt(str);

    //Prepare Result
    kernel->machine->WriteRegister(2, (int)result);
    return upProgramCounter();
}

void 
handle_SC_PrintNum(){
    int num = (int)kernel->machine->ReadRegister(4);
    //Change numbers to string
    char* str = toString(num);
    //Display string of numbers
    kernel->synchConsoleOut->PutString(str);
    return upProgramCounter();
}

void 
handle_SC_ReadChar(){
    char* ch = kernel->synchConsoleIn->GetString();
    kernel->machine->WriteRegister(2,(int)ch[0]);
    return upProgramCounter();
}

void 
handle_SC_PrintChar(){
    int num = (int)kernel->machine->ReadRegister(4);
    char ch = char(num);

    kernel->synchConsoleOut->PutChar(ch);
    return upProgramCounter();
}

void
handle_SC_RandomNum(){
    int rdNum = sysRandomNum();

    kernel->machine->WriteRegister(2,rdNum);
    return upProgramCounter();
}

void 
handle_SC_ReadString(){
    int len = (int)kernel->machine->ReadRegister(5);
    int buffAddrUser = (int)kernel->machine->ReadRegister(4);

    char* buff = new char[len + 1];
    buff = kernel->synchConsoleIn->GetString();
    
    // Copy buffer from System memory space to User memory space
    System2User(buffAddrUser, len, buff);
    return upProgramCounter();
}

void
handle_SC_PrintString(){
    int buffAddr = (int)kernel->machine->ReadRegister(4);
    char* buff = new char[LIMIT];

    buff = User2System(buffAddr, LIMIT);

    // Copy buffer from User memory space to System memory space
    kernel->synchConsoleOut->PutString(buff);
    return upProgramCounter();
}

void 
handle_SC_CreateFile(){
    int virtaddr;
    char* filename;

    virtaddr = kernel->machine->ReadRegister(4);

    filename = User2System(virtaddr, MaxFileLength + 1);

    //Kiem tra filename co hop le hay khong
    if(strlen(filename) == 0){
        printf("Ten file khong duoc la khoang trang!\n");
        kernel->machine->WriteRegister(2, -1);
    }

    //Khi he thong khong co du bo nho
    else if(filename == NULL){
        printf("Khong du bo nho de tao file!\n");
        kernel->machine->WriteRegister(2, -1);
    }
    
    //Tao file khong thanh cong
    else if(!kernel->fileSystem->Create(filename)){
        printf("Tao file khong thanh cong!\n");
        kernel->machine->WriteRegister(2, -1);
    }

    //Tao file thanh cong
    else {
        printf("Tao file thanh cong!\n");
        kernel->machine->WriteRegister(2, 0);
    }
    delete[] filename;

    return upProgramCounter();
} 

void 
handle_SC_Open()
{

    int virAddr; //file address
    char *filename; // buffer file name
    int emptyslot; 
    OpenFile *file;

    virAddr = kernel->machine->ReadRegister(4); //Doc thanh ghi de lay dia chi filename
    //Chuyen vung nho tu user sang he thong de he thong get duoc filename
    filename = User2System(virAddr, MaxFileLength + 1);

    emptyslot = kernel->fileSystem->FindAnEmptySlot(); //Kiem slot con trong trong file open table

    file = kernel->fileSystem->Open(filename);
    
    if (file == NULL || emptyslot == -1) //Khong the Mo File hoac khong con slot 
    {
        printf("Khong the mo file hoac khong con slot!\n");
        kernel->machine->WriteRegister(2, -1); //Ghi vao thanh ghi thu 2 la -1
        delete file;
        delete[] filename;
    }
    else  //Neu con empty slot trong file open talbe
    {
        printf("Mo file \"%s\" thanh cong!\n", filename);
        kernel->fileSystem->fileOpenTable[emptyslot] = file;
        kernel->fileSystem->fileNameTable[emptyslot] = filename;
        kernel->machine->WriteRegister(2, emptyslot); //Ghi vao thanh ghi thu 2 la id
    }
    return upProgramCounter(); 
}


void
handle_SC_Close()
{
    int fileID;
    fileID = kernel->machine->ReadRegister(4);

    if (0 <= fileID && fileID < MAXOPENFILE) //Kiem tra xem id co nam trong mien gioi han Table khong
    {
        if (kernel->fileSystem->fileOpenTable[fileID] != NULL) //Neu mo file thanh cong
        {
            printf("Close file thanh cong!\n");
            delete kernel->fileSystem->fileOpenTable[fileID];    
            kernel->fileSystem->fileOpenTable[fileID] = NULL; 
            
            delete kernel->fileSystem->fileNameTable[fileID]; 
            kernel->fileSystem->fileNameTable[fileID] = NULL; 
            
            kernel->machine->WriteRegister(2, 0);  
        }
        else
        {
            printf("Khong ton tai file trong FILE TABLE!\n"); 
            kernel->machine->WriteRegister(2, -1); 
        }
    }
    else {
        printf("\nVuot qua gioi han FILE TABLE!\n"); 
        kernel->machine->WriteRegister(2, -1); 
    }
    return upProgramCounter(); 
}

void 
handle_SC_ReadFile(){
    int virtAddr = kernel->machine->ReadRegister(4),    //Địa chỉ chuỗi buffer
        charCnt = kernel->machine->ReadRegister(5),     //Độ dài của chuỗi
        openF_id = kernel->machine->ReadRegister(6);    //id của file
    int curPos, newPos, readB;
    char *sysBuff;
    
    //Kiem tra id File trong vung gioi han cua File table
    if(openF_id < 0 || openF_id >= MAXOPENFILE){
        printf("File id vuot qua mien gioi han cua File table!\n");
        kernel->machine->WriteRegister(2, -1);
    }

    //Kiem tra su ton tai cua id file
    else if(kernel->fileSystem->fileOpenTable[openF_id] == NULL){
        printf("File id khong ton tai trong File table!\n");
        kernel->machine->WriteRegister(2, -1);
    }

    //Xet truong hop doc file stdout (duoc quy dinh la 1)   
    else if (openF_id == NUMBER_STDOUT){   
        printf("\nKhong the doc trong console output!\n");
        kernel->machine->WriteRegister(2,-1);  
    }
    else{

        // Lay vi tri current position
        curPos = kernel->fileSystem->fileOpenTable[openF_id]->getCurrentOffset(); 

        printf("Nhan enter de tiep tuc...\n");
        //Lay chuoi tu console
        sysBuff = kernel->synchConsoleIn->GetString(); 

        //Truong hop doc file la stdin (duoc quy dinh la 0)
        if (openF_id == NUMBER_STDIN){
            printf("Doc file stdin!\n");
            System2User(virtAddr, strlen(sysBuff), sysBuff); 
            kernel->machine->WriteRegister(2, strlen(sysBuff)); //Ghi vao thanh ghi thu 2 la so byte read
        }
        //Truong hop doc file binh thuong
        else if((kernel->fileSystem->fileOpenTable[openF_id]->Read(sysBuff, charCnt)) > 0){
            printf("Read file thanh cong!\n");
            // So byte thuc su = newPos - curPos
            newPos = kernel->fileSystem->fileOpenTable[openF_id]->getCurrentOffset();
            
            /* Copy chuoi tu vung nho System Space sang User Space voi buffer co do
            dai la readB (so byte that su da doc)*/
            readB = newPos - curPos;

            System2User(virtAddr, readB, sysBuff);

            kernel->machine->WriteRegister(2, readB);  //Ghi vao thanh ghi thu 2 la so byte read
        }
        else // Truong hop con lai la doc file co noi dung la NULL
        {
            printf("File khong co ki tu de read!\n");
            kernel->machine->WriteRegister(2, -1);  //Ghi vao thanh ghi thu 2 la -1
        }        
        delete[] sysBuff;
    }
    return upProgramCounter();
}

void 
handle_SC_WriteFile(){
    int virtAddr = kernel->machine->ReadRegister(4),    //Địa chỉ chuỗi buffer
        charCnt = kernel->machine->ReadRegister(5),     //Độ dài của chuỗi
        openF_id = kernel->machine->ReadRegister(6);    //id của file
    int curPos, newPos, wirteB;
    char *sysBuff;
    
    //Kiem tra id File trong vung gioi han cua File table
    if(openF_id < 0 || openF_id >= MAXOPENFILE){
        printf("File id vuot qua mien gioi han cua File table!\n");
        kernel->machine->WriteRegister(2, -1);
    }

    //Kiem tra su ton tai cua id file
    else if(kernel->fileSystem->fileOpenTable[openF_id] == NULL){
        printf("File id khong ton tai trong File table!\n");
        kernel->machine->WriteRegister(2, -1);
    }

    //Xet truong hop doc file stdout (duoc quy dinh la 1)   
    else if (openF_id == NUMBER_STDIN){   
        printf("\nKhong the doc trong console input!\n");
        kernel->machine->WriteRegister(2,-1);  
    }
    else{
        // Lay vi tri current position
        curPos = kernel->fileSystem->fileOpenTable[openF_id]->getCurrentOffset(); 

        // Copy vung nho User Space sang System space voi buffer do dai charCnt bytes + 1
        sysBuff = User2System(virtAddr, charCnt);

        //Xet truong hop doc file stdout(duoc quy dinh la 1)
        if(openF_id == NUMBER_STDOUT){
            printf("Doc file stdout!\n");

            kernel->synchConsoleOut->PutString(sysBuff); //In ra chuoi ra console
            
            kernel->machine->WriteRegister(2, strlen(sysBuff));
        }
        //Truong hop ghi file binh thuong
        else if((kernel->fileSystem->fileOpenTable[openF_id]->Write(sysBuff, charCnt)) > 0){
            printf("Write file thanh cong!\n");

            // So byte thuc su = newPosition - curPosition
            newPos = kernel->fileSystem->fileOpenTable[openF_id]->getCurrentOffset();
            wirteB = newPos - curPos;
            kernel->machine->WriteRegister(2, wirteB);
        }
        else {
            printf("Write file khong thanh cong!\n");
            kernel->machine->WriteRegister(2, -1);
        }
        delete[] sysBuff;
    }
    return upProgramCounter();
}

void 
handle_SC_Seek()
{
    int position;
    int id;

    position = kernel->machine->ReadRegister(4); // Lay vi tri can chuyen con tro den trong file
    id = kernel->machine->ReadRegister(5);  // Lay id cua file

    if (id < 0 || id >= MAXOPENFILE) 
    {
        kernel->machine->WriteRegister(2,-1);  

    }
    //Kiem tra file tai id do co ton tai hay khong
    else if (kernel->fileSystem->fileOpenTable[id] == NULL)
    {
        kernel->machine->WriteRegister(2,-1);  
    }
    // Kiem tra seek da duoc goi tren console hay chua
    else if (id == NUMBER_STDIN || id == NUMBER_STDOUT)
    {
        kernel->machine->WriteRegister(2,-1);  //Ghi vao thanh ghi thu 2 la -1
    }

    /*Gan gia tri la length neu possition = -1*/
    if (position == -1) position = kernel->fileSystem->fileOpenTable[id]->Length();

    // Kiem tra vi tri co hop le hay khong
    if (position > kernel->fileSystem->fileOpenTable[id]->Length() || position < 0)
    {
        kernel->machine->WriteRegister(2, -1);  //Ghi vao thanh ghi thu 2 la -1
    }
    else //Truong hop con lai la vi tri hop le
    {
        printf("Con tro da duoc dua toi vi tri %d cua file \"%s\".\n", position, kernel->fileSystem->fileNameTable[id]);
        kernel->fileSystem->fileOpenTable[id]->Seek(position);
        kernel->machine->WriteRegister(2, position);  //Ghi vao thanh ghi thu 2 la position
    }
    return upProgramCounter(); 
}


void
handle_SC_RemoveFile(){
    int addr = kernel->machine->ReadRegister(4); //Lay dia chi cua filename trong user
    char* fileName = User2System(addr, LIMIT);
    OpenFile* f;
    f = kernel->fileSystem->Open(fileName);

    //Khong mo duoc file
    if(f == NULL){
        printf("File \"%s\" khong ton tai.\n", fileName);
        kernel->machine->WriteRegister(2, -1);
    }
    else{
        //Neu dang mo thi close tat ca cac file co filename nay dang duoc mo
        kernel->fileSystem->CloseFile(fileName);

        //Xoa file
        kernel->fileSystem->Remove(fileName);   
        printf("File \"%s\" da duoc remove.\n", fileName); 
        kernel->machine->WriteRegister(2, 0);
    }
    delete f;
    delete[] fileName;
    return upProgramCounter();
}
#endif /* ! __USERPROG_KSYSCALL_H__ */
